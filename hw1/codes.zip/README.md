This is the codes for problem 1, 3, 4 and 5.

 

Problem 1:

p1.py is the simulation of problem 1.

 

Problem 3:

p3.py can plot figures for problem 3b.

 

Problem 4:

p4_util.py includes some useful function for problem 4.

 

p4_LCA.py uses Label-Correcting Algorithm and main function.

 

 

Problem 5:

 

p5_bayes.py contains functions and main function for problem 5.
