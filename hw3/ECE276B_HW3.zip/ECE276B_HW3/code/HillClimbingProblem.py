import gym


class Planner:

	'''
	Initialization of all necessary variables to generate a policy:
		discretized state space
		control space
		discount factor
		learning rate
		greedy probability (if applicable)
	'''
	def __init__(self):
		pass

	'''
	Learn and return a policy via model-free policy iteration.
	'''
	def __call__(self, mc=False, on=True):
		return self._td_policy_iter(on)


	'''
	TO BE IMPLEMENT
	TD Policy Iteration
	Flags: on : on vs. off policy learning
	Returns: policy that minimizes Q wrt to controls
	'''
	def _td_policy_iter(self, on=True):
		pass


	'''
	Sample trajectory based on a policy
	'''
	def rollout(self, env, policy=None, render=False):
		traj = []
		t = 0
		done = False
		c_state = env.reset()
		if policy is None:
			while not done or t < 200:
				action = env.action_space.sample()
				if render:
					env.render()
				n_state, reward, done, _ = env.step(action)
				traj.append((c_state, action, reward))
				c_state = n_state
				t += 1

			env.close()
			return traj

		else:
			while not done or t < 200:
				action = policy(c_state)
				if render:
					env.render

				n_state, reward, done, _ = env.step(action)
				traj.append((c_state, action, reward))
				c_state = n_state
				t += 1

			env.close()
			return traj


if __name__ == '__main__':

	env = gym.make('MountainCar-v0')
	planner = Planner()
	traj = planner.rollout(env, policy=None, render=True)
	print(traj)

