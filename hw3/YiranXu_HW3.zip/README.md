There are 9 files in this zip except README.md.

1.  P1_utils.py includes some useful functions for problem 1.

2.  P1.py is the program for Problem 1 (b) \~ (d).

3.  P2.py is the program for Problem 2. Uncomment lines in main() for different
    algorithms

4.  HillClimbingProblem.py is the program for Problem 3.

5.  P4.py is the program for problem 4.

6.  Mountain Car.mp4 is a qualitative result for problem 3.

7.  double_pendulum_VI.mp4 is a qualitative result using VI algorithm.

8.  double_pendulum_PI.mp4 is a qualitative result using PI algorithm.

9.  double_pendulum_noise1e0 is a qualitative result with a big noise whose
    sigma matrix = [1,0;0,1]
